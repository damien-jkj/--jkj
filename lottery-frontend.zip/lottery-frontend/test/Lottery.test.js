const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Lottery Contract", function () {
  let Lottery;
  let lottery;
  let owner;
  let player1;
  let player2;

  beforeEach(async function () {
    [owner, player1, player2] = await ethers.getSigners();
    Lottery = await ethers.getContractFactory("Lottery");
    lottery = await Lottery.deploy();
  });

  it("Should deploy with the correct manager", async function () {
    expect(await lottery.manager()).to.equal(owner.address);
  });

  it("Should allow players to enter", async function () {
    await lottery.connect(player1).enter({ value: ethers.parseEther("0.1") });
    const players = await lottery.getPlayers();
    expect(players[0]).to.equal(player1.address);
  });
});
const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Lottery Contract", function () {
  let Lottery;
  let lottery;
  let owner;
  let player1;
  let player2;

  beforeEach(async function () {
    [owner, player1, player2] = await ethers.getSigners();
    Lottery = await ethers.getContractFactory("Lottery");
    lottery = await Lottery.deploy();
  });

  it("Should deploy with the correct manager", async function () {
    expect(await lottery.manager()).to.equal(owner.address);
  });

  it("Should allow players to enter", async function () {
    await lottery.connect(player1).enter({ value: ethers.parseEther("0.1") });
    const players = await lottery.getPlayers();
    expect(players[0]).to.equal(player1.address);
  });
});
