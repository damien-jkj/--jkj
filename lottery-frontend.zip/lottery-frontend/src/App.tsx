import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Layout, Menu } from 'antd';
import { TrophyOutlined, ShopOutlined } from '@ant-design/icons';
import LotteryPage from './pages/lottery';
import MarketplacePage from './pages/marketplace';
import './App.css';

const { Header, Content } = Layout;

// 菜单项配置
const menuItems = [
  {
    key: '1',
    icon: <TrophyOutlined />,
    label: <Link to="/">彩票投注</Link>,
  },
  {
    key: '2', 
    icon: <ShopOutlined />,
    label: <Link to="/marketplace">交易市场</Link>,
  },
];

function App() {
  return (
    <Router>
      <Layout className="layout">
        <Header>
          <div className="logo">🎰 区块链彩票</div>
          <Menu 
            theme="dark" 
            mode="horizontal" 
            defaultSelectedKeys={['1']}
            items={menuItems}
          />
        </Header>
        <Content style={{ padding: '0 50px' }}>
          <div className="site-layout-content">
            <Routes>
              <Route path="/" element={<LotteryPage />} />
              <Route path="/marketplace" element={<MarketplacePage />} />
            </Routes>
          </div>
        </Content>
      </Layout>
    </Router>
  );
}

export default App;
