interface Window {
    ethereum?: any;
    web3?: any;
    Web3?: any;
}
