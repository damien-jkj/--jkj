import { useState, useEffect } from 'react';
import { Card, Button, List, Input, Modal, message } from 'antd';
import { myERC721Contract, web3 } from '../../utils/contracts';
import './index.css';

interface Ticket {
  tokenId: number;
  eventId: number;
  optionId: number;
  price: string;
  isForSale: boolean;
  seller: string;
}

const MarketplacePage = () => {
  const [account, setAccount] = useState('');
  const [myTickets, setMyTickets] = useState<Ticket[]>([]);
  const [marketTickets, setMarketTickets] = useState<Ticket[]>([]);
  const [sellModalVisible, setSellModalVisible] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [sellPrice, setSellPrice] = useState('');

  useEffect(() => {
    loadAccount();
    loadTickets();
  }, []);

  const loadAccount = async () => {
    const accounts = await web3.eth.getAccounts();
    if (accounts.length > 0) {
      setAccount(accounts[0]);
    }
  };

  const loadTickets = async () => {
    try {
      // 获取活跃的销售订单
      const activeOrders = await myERC721Contract.methods.getActiveSellOrders().call();
      
      const marketTicketsList: Ticket[] = [];
      const myTicketsList: Ticket[] = [];

      // 加载市场中的票
      for (const tokenId of activeOrders) {
        const ticketInfo = await myERC721Contract.methods.getTicketInfo(tokenId).call();
        if (ticketInfo.isForSale) {
          marketTicketsList.push({
            tokenId: Number(tokenId),
            eventId: Number(ticketInfo.eventId),
            optionId: Number(ticketInfo.optionId),
            price: web3.utils.fromWei(ticketInfo.price, 'ether'),
            isForSale: ticketInfo.isForSale,
            seller: ticketInfo.seller
          });
        }
      }

      // 加载我的票（简化版本，实际应该用 ERC721 的 balanceOf 和 tokenOfOwnerByIndex）
      // 这里我们假设能获取到前20个token来检查所有权
      for (let i = 1; i <= 20; i++) {
        try {
          const owner = await myERC721Contract.methods.ownerOf(i).call();
          if (owner.toLowerCase() === account.toLowerCase()) {
            const ticketInfo = await myERC721Contract.methods.getTicketInfo(i).call();
            myTicketsList.push({
              tokenId: i,
              eventId: Number(ticketInfo.eventId),
              optionId: Number(ticketInfo.optionId),
              price: web3.utils.fromWei(ticketInfo.price, 'ether'),
              isForSale: ticketInfo.isForSale,
              seller: ticketInfo.seller
            });
          }
        } catch (error) {
          // token 可能不存在，继续下一个
        }
      }

      setMarketTickets(marketTicketsList);
      setMyTickets(myTicketsList);
    } catch (error) {
      console.error('加载票务信息失败:', error);
    }
  };

  const handleSell = (ticket: Ticket) => {
    setSelectedTicket(ticket);
    setSellModalVisible(true);
  };

  const confirmSell = async () => {
    if (!selectedTicket || !sellPrice) return;

    try {
      const priceInWei = web3.utils.toWei(sellPrice, 'ether');
      await myERC721Contract.methods.listForSale(selectedTicket.tokenId, priceInWei).send({
        from: account
      });
      
      message.success('挂单成功！');
      setSellModalVisible(false);
      setSellPrice('');
      loadTickets(); // 刷新数据
    } catch (error: any) {
      message.error('挂单失败: ' + error.message);
    }
  };

  const handleBuy = async (ticket: Ticket) => {
    try {
      const priceInWei = web3.utils.toWei(ticket.price, 'ether');
      await myERC721Contract.methods.buyTicket(ticket.tokenId).send({
        from: account,
        value: priceInWei
      });
      
      message.success('购买成功！');
      loadTickets(); // 刷新数据
    } catch (error: any) {
      message.error('购买失败: ' + error.message);
    }
  };

  const handleCancelSale = async (ticket: Ticket) => {
    try {
      await myERC721Contract.methods.cancelSale(ticket.tokenId).send({
        from: account
      });
      
      message.success('取消挂单成功！');
      loadTickets(); // 刷新数据
    } catch (error: any) {
      message.error('取消挂单失败: ' + error.message);
    }
  };

  return (
    <div className="marketplace-container">
      <h1>🎫 彩票交易市场</h1>
      
      <div className="marketplace-content">
        {/* 我的票务 */}
        <Card title="📋 我的彩票" style={{ marginBottom: 24 }}>
          <List
            dataSource={myTickets}
            renderItem={(ticket) => (
              <List.Item
                actions={[
                  !ticket.isForSale ? (
                    <Button type="primary" onClick={() => handleSell(ticket)}>
                      出售
                    </Button>
                  ) : (
                    <Button onClick={() => handleCancelSale(ticket)}>
                      取消出售
                    </Button>
                  )
                ]}
              >
                <List.Item.Meta
                  title={`彩票 #${ticket.tokenId}`}
                  description={
                    <div>
                      <div>事件: {ticket.eventId} | 选项: {ticket.optionId}</div>
                      <div>状态: {ticket.isForSale ? `出售中 - ${ticket.price} ETH` : '未出售'}</div>
                    </div>
                  }
                />
              </List.Item>
            )}
          />
        </Card>

        {/* 市场票务 */}
        <Card title="🛒 市场交易">
          <List
            dataSource={marketTickets}
            renderItem={(ticket) => (
              <List.Item
                actions={[
                  <Button 
                    type="primary" 
                    onClick={() => handleBuy(ticket)}
                    disabled={ticket.seller.toLowerCase() === account.toLowerCase()}
                  >
                    购买
                  </Button>
                ]}
              >
                <List.Item.Meta
                  title={`彩票 #${ticket.tokenId}`}
                  description={
                    <div>
                      <div>事件: {ticket.eventId} | 选项: {ticket.optionId}</div>
                      <div>价格: {ticket.price} ETH</div>
                      <div>卖家: {ticket.seller.slice(0, 6)}...{ticket.seller.slice(-4)}</div>
                    </div>
                  }
                />
              </List.Item>
            )}
          />
        </Card>
      </div>

      {/* 出售弹窗 */}
      <Modal
        title="出售彩票"
        open={sellModalVisible}
        onOk={confirmSell}
        onCancel={() => setSellModalVisible(false)}
      >
        {selectedTicket && (
          <div>
            <p>彩票 #{selectedTicket.tokenId}</p>
            <Input
              placeholder="输入出售价格 (ETH)"
              value={sellPrice}
              onChange={(e) => setSellPrice(e.target.value)}
              type="number"
            />
          </div>
        )}
      </Modal>
    </div>
  );
};

export default MarketplacePage;