import Addresses from './contract-addresses.json'
import Lottery from './abis/Lottery.json'
import MyERC20 from './abis/MyERC20.json'
import MyERC721 from './abis/MyERC721.json'

// 使用全局的 Web3（来自 CDN）
declare const Web3: any;

// 直接初始化并导出
let web3: any;
let lotteryContract: any;
let myERC20Contract: any;
let myERC721Contract: any;

// 立即执行初始化
(function initializeContracts() {
    console.log('=== 初始化合约 ===');
    
    try {
        if (typeof window !== 'undefined' && (window as any).ethereum) {
            web3 = new Web3((window as any).ethereum);
            console.log('✅ 使用 ethereum provider 初始化 web3');
        } else {
            web3 = new Web3('http://127.0.0.1:8545');
            console.log('✅ 使用 HTTP provider 初始化 web3');
        }

        const lotteryAddress = Addresses.lottery;
        const lotteryABI = Lottery.abi;
        const myERC20Address = Addresses.myERC20;
        const myERC20ABI = MyERC20.abi;
        const myERC721Address = Addresses.myERC721;
        const myERC721ABI = MyERC721.abi;

        lotteryContract = new web3.eth.Contract(lotteryABI, lotteryAddress);
        myERC20Contract = new web3.eth.Contract(myERC20ABI, myERC20Address);
        myERC721Contract = new web3.eth.Contract(myERC721ABI, myERC721Address);

        console.log('✅ 合约实例创建完成');
        
        // 🔧 关键修复：暴露到 window 对象，这样在 Console 中也可以访问
        if (typeof window !== 'undefined') {
            (window as any).appWeb3 = web3;
            (window as any).appLotteryContract = lotteryContract;
            (window as any).appMyERC20Contract = myERC20Contract;
            (window as any).appMyERC721Contract = myERC721Contract; 
            console.log('✅ 合约对象已暴露到 window');
        }
        
    } catch (error) {
        console.error('❌ 合约初始化失败:', error);
    }
})();

export { web3, lotteryContract, myERC20Contract, myERC721Contract };