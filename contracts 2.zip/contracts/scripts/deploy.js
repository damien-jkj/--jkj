const { ethers } = require("hardhat");

async function main() {
  console.log("🚀 Starting deployment to Ganache...");
  
  // 获取部署者信息
  const [deployer] = await ethers.getSigners();
  console.log("Deployer address:", deployer.address);
  console.log("Deployer balance:", (await ethers.provider.getBalance(deployer.address)).toString());
  
  // 部署 Lottery 合约
  console.log("📝 Deploying Lottery contract...");
  const Lottery = await ethers.getContractFactory("Lottery");
  const lottery = await Lottery.deploy();
  
  // 使用兼容性更好的方法
  await lottery.deployed();
  const lotteryAddress = lottery.address;
  console.log(`✅ Lottery contract deployed to: ${lotteryAddress}`);

  // 获取自动部署的 MyERC20 合约地址
  const erc20Address = await lottery.myERC20();
  console.log(`✅ MyERC20 contract deployed to: ${erc20Address}`);
  
  // 验证合约信息
  console.log("📋 Contract details:");
  console.log("   Manager:", await lottery.manager());
  console.log("   Play amount:", (await lottery.PLAY_AMOUNT()).toString());
  console.log("   Player number:", (await lottery.getPlayerNumber()).toString());
  console.log("   Total amount:", (await lottery.totalAmount()).toString());
  
  console.log("🎉 Deployment completed successfully!");
}

main().catch((error) => {
  console.error("💥 Deployment failed:", error);
  process.exitCode = 1;
});
