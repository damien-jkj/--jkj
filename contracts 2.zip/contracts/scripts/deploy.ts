import { ethers } from "hardhat";

async function main() {
  console.log("Deploying contracts...");
  
  // 部署 MyERC20
  const MyERC20 = await ethers.getContractFactory("MyERC20");
  const myERC20 = await MyERC20.deploy("ZJU Token", "ZJU");
  await myERC20.deployed();
  console.log("MyERC20 deployed to:", myERC20.address);
  
  // 部署 MyERC721
  const MyERC721 = await ethers.getContractFactory("MyERC721");
  const myERC721 = await MyERC721.deploy();
  await myERC721.deployed();
  console.log("MyERC721 deployed to:", myERC721.address);
  
  // 部署 Lottery（需要两个合约地址）
  const Lottery = await ethers.getContractFactory("Lottery");
  const lottery = await Lottery.deploy(myERC20.address, myERC721.address);
  await lottery.deployed();
  console.log("Lottery deployed to:", lottery.address);
  
  // 保存地址到文件（供前端使用）
  const fs = require('fs');
  const addresses = {
    myERC20: myERC20.address,
    myERC721: myERC721.address,
    lottery: lottery.address
  };
  
  fs.writeFileSync('../lottery-frontend/src/utils/contract-addresses.json', 
    JSON.stringify(addresses, null, 2));
  
  console.log("Addresses saved to frontend!");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
