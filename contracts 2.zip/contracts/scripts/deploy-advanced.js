const { ethers } = require("hardhat");

async function main() {
  console.log("🚀 Deploying Advanced Lottery System...");
  
  const [deployer] = await ethers.getSigners();
  console.log("Deployer address:", deployer.address);
  console.log("Deployer balance:", (await ethers.provider.getBalance(deployer.address)).toString());
  
  // 部署 AdvancedLottery 合约（它会自动部署 LotteryNFT）
  console.log("📝 Deploying AdvancedLottery contract...");
  const AdvancedLottery = await ethers.getContractFactory("AdvancedLottery");
  const advancedLottery = await AdvancedLottery.deploy();
  
  await advancedLottery.deployed();
  const advancedLotteryAddress = advancedLottery.address;
  console.log("✅ AdvancedLottery deployed to:", advancedLotteryAddress);

  // 获取自动部署的 LotteryNFT 合约地址
  const lotteryNFTAddress = await advancedLottery.lotteryNFT();
  console.log("✅ LotteryNFT deployed to:", lotteryNFTAddress);
  
  // 验证合约信息
  console.log("📋 Contract details:");
  console.log("   Owner:", await advancedLottery.owner());
  console.log("   Event count:", (await advancedLottery.getEventCount()).toString());
  
  console.log("🎉 Advanced Lottery deployment completed!");
  console.log("\n📝 Contract addresses for frontend:");
  console.log("   AdvancedLottery:", advancedLotteryAddress);
  console.log("   LotteryNFT:", lotteryNFTAddress);
}

main().catch((error) => {
  console.error("💥 Deployment failed:", error);
  process.exit(1);
});
