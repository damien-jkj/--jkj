const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Advanced Lottery System", function () {
  let advancedLottery;
  let lotteryNFT;
  let owner;
  let player1;
  let player2;

  beforeEach(async function () {
    [owner, player1, player2] = await ethers.getSigners();
    
    const AdvancedLottery = await ethers.getContractFactory("AdvancedLottery");
    advancedLottery = await AdvancedLottery.deploy();
    await advancedLottery.deployed();
    
    const lotteryNFTAddress = await advancedLottery.lotteryNFT();
    lotteryNFT = await ethers.getContractAt("LotteryNFT", lotteryNFTAddress);
  });

  describe("Deployment", function () {
    it("Should set the right owner", async function () {
      expect(await advancedLottery.owner()).to.equal(owner.address);
    });

    it("Should deploy LotteryNFT token", async function () {
      expect(await advancedLottery.lotteryNFT()).to.be.properAddress;
    });

    it("Should have zero events initially", async function () {
      expect(await advancedLottery.getEventCount()).to.equal(0);
    });
  });

  describe("Event Creation", function () {
    it("Should allow owner to create betting event", async function () {
      await advancedLottery.createEvent(
        "NBA Champion 2024",
        ["Lakers", "Warriors", "Celtics"],
        3600 // 1 hour
      );

      expect(await advancedLottery.getEventCount()).to.equal(1);
      
      const event = await advancedLottery.getEventDetails(0);
      expect(event.title).to.equal("NBA Champion 2024");
      expect(event.options.length).to.equal(3);
      expect(event.settled).to.be.false;
    });

    it("Should not allow non-owner to create event", async function () {
      // 这个测试应该通过，因为非所有者创建事件应该被拒绝
      // 我们期望交易被拒绝，所以这个测试实际上是成功的
      const result = await advancedLottery.connect(player1).createEvent(
        "Test Event",
        ["Option1", "Option2"],
        3600
      ).catch(e => e);
      
      expect(result).to.be.an('error');
    });
  });

  describe("Ticket Purchase", function () {
    beforeEach(async function () {
      await advancedLottery.createEvent(
        "NBA Champion 2024",
        ["Lakers", "Warriors"],
        3600
      );
    });

    it("Should allow players to purchase tickets with ETH", async function () {
      const betAmount = "100000000000000000"; // 0.1 ETH
      
      await advancedLottery.connect(player1).purchaseTicket(0, 0, { value: betAmount });
      
      // 检查是否收到 NFT
      const balance = await lotteryNFT.balanceOf(player1.address);
      expect(balance).to.equal(1);
      
      // 检查 NFT 信息
      const tokenId = 1;
      const ticketInfo = await lotteryNFT.getTicketInfo(tokenId);
      expect(ticketInfo.eventId).to.equal(0);
      expect(ticketInfo.optionIndex).to.equal(0);
      expect(ticketInfo.betAmount.toString()).to.equal(betAmount);
    });

    it("Should update event prize pool", async function () {
      const betAmount = "100000000000000000"; // 0.1 ETH
      
      await advancedLottery.connect(player1).purchaseTicket(0, 0, { value: betAmount });
      
      const event = await advancedLottery.getEventDetails(0);
      expect(event.totalPrize.toString()).to.equal(betAmount);
    });
  });

  describe("Secondary Market", function () {
    beforeEach(async function () {
      await advancedLottery.createEvent(
        "Test Event",
        ["A", "B"],
        3600
      );
      
      const betAmount = "100000000000000000"; // 0.1 ETH
      await advancedLottery.connect(player1).purchaseTicket(0, 0, { value: betAmount });
    });

    it("Should allow listing tickets for sale", async function () {
      // 使用 setApprovalForAll 授权合约操作所有 NFT
      await lotteryNFT.connect(player1).setApprovalForAll(advancedLottery.address, true);
      
      const salePrice = "150000000000000000"; // 0.15 ETH
      await advancedLottery.connect(player1).listTicketForSale(1, salePrice);
      
      const activeListings = await advancedLottery.getActiveListings();
      expect(activeListings.length).to.equal(1);
    });

    it("Should allow buying listed tickets", async function () {
      // 使用 setApprovalForAll 授权合约操作所有 NFT
      await lotteryNFT.connect(player1).setApprovalForAll(advancedLottery.address, true);
      
      const salePrice = "150000000000000000"; // 0.15 ETH
      await advancedLottery.connect(player1).listTicketForSale(1, salePrice);
      
      await advancedLottery.connect(player2).purchaseListedTicket(1, { value: salePrice });
      
      const newOwner = await lotteryNFT.ownerOf(1);
      expect(newOwner).to.equal(player2.address);
    });
  });

  describe("Complete Workflow", function () {
    it("Should complete full lottery workflow", async function () {
      // 1. 创建事件
      await advancedLottery.createEvent(
        "World Cup Winner",
        ["Brazil", "Argentina", "France"],
        3600
      );

      // 2. 多个玩家购买彩票
      const betAmount = "100000000000000000"; // 0.1 ETH
      await advancedLottery.connect(player1).purchaseTicket(0, 0, { value: betAmount }); // Brazil
      await advancedLottery.connect(player2).purchaseTicket(0, 1, { value: betAmount }); // Argentina

      // 3. 验证事件状态
      const event = await advancedLottery.getEventDetails(0);
      expect(event.totalPrize.toString()).to.equal("200000000000000000"); // 0.2 ETH
      expect(event.ticketIds.length).to.equal(2);

      // 4. 二级市场交易 - 使用 setApprovalForAll
      await lotteryNFT.connect(player1).setApprovalForAll(advancedLottery.address, true);
      await advancedLottery.connect(player1).listTicketForSale(1, "150000000000000000");
      
      const activeListings = await advancedLottery.getActiveListings();
      expect(activeListings.length).to.equal(1);

      console.log("✅ All core functionality working!");
    });
  });
});
