const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Lottery Contract", function () {
  let lottery;
  let myERC20;
  let owner;
  let player1;
  let player2;

  beforeEach(async function () {
    [owner, player1, player2] = await ethers.getSigners();
    
    const Lottery = await ethers.getContractFactory("Lottery");
    lottery = await Lottery.deploy();
    
    const myERC20Address = await lottery.myERC20();
    myERC20 = await ethers.getContractAt("MyERC20", myERC20Address);
  });

  describe("Deployment", function () {
    it("Should set the right manager", async function () {
      expect(await lottery.manager()).to.equal(owner.address);
    });

    it("Should deploy MyERC20 token", async function () {
      expect(await lottery.myERC20()).to.be.properAddress;
    });

    it("Should have correct play amount", async function () {
      expect(await lottery.PLAY_AMOUNT()).to.equal(500);
    });
  });

  describe("Token Airdrop", function () {
    it("Should allow users to claim airdrop", async function () {
      await myERC20.connect(player1).airdrop();
      const balance = await myERC20.balanceOf(player1.address);
      expect(balance).to.equal(10000);
    });

    it("Should prevent double claiming", async function () {
      await myERC20.connect(player1).airdrop();
      await expect(myERC20.connect(player1).airdrop()).to.be.revertedWith("This user has claimed airdrop already");
    });
  });

  describe("Playing Lottery", function () {
    it("Should allow players to play with tokens", async function () {
      await myERC20.connect(player1).airdrop();
      const lotteryAddress = lottery.target || lottery.address;
      await myERC20.connect(player1).approve(lotteryAddress, 1000);
      
      await lottery.connect(player1).play();
      expect(await lottery.getPlayerNumber()).to.equal(1);
      expect(await lottery.totalAmount()).to.equal(500);
    });

    it("Should track multiple players", async function () {
      await myERC20.connect(player1).airdrop();
      await myERC20.connect(player2).airdrop();
      const lotteryAddress = lottery.target || lottery.address;
      await myERC20.connect(player1).approve(lotteryAddress, 1000);
      await myERC20.connect(player2).approve(lotteryAddress, 1000);
      
      await lottery.connect(player1).play();
      await lottery.connect(player2).play();
      
      expect(await lottery.getPlayerNumber()).to.equal(2);
      expect(await lottery.totalAmount()).to.equal(1000);
    });

    it("Should fail if player has insufficient tokens", async function () {
      const lotteryAddress = lottery.target || lottery.address;
      await myERC20.connect(player1).approve(lotteryAddress, 1000);
      await expect(lottery.connect(player1).play()).to.be.reverted;
    });

    it("Should fail if not approved", async function () {
      await myERC20.connect(player1).airdrop();
      await expect(lottery.connect(player1).play()).to.be.reverted;
    });
  });

  describe("Drawing Winner", function () {
    it("Should select a winner and transfer tokens", async function () {
      await myERC20.connect(player1).airdrop();
      await myERC20.connect(player2).airdrop();
      const lotteryAddress = lottery.target || lottery.address;
      await myERC20.connect(player1).approve(lotteryAddress, 1000);
      await myERC20.connect(player2).approve(lotteryAddress, 1000);
      
      await lottery.connect(player1).play();
      await lottery.connect(player2).play();

      const initialContractBalance = await myERC20.balanceOf(lotteryAddress);
      expect(initialContractBalance).to.equal(1000);
      
      await lottery.draw();
      
      const finalContractBalance = await myERC20.balanceOf(lotteryAddress);
      expect(finalContractBalance).to.equal(0);
      
      expect(await lottery.getPlayerNumber()).to.equal(0);
      expect(await lottery.totalAmount()).to.equal(0);
    });

    it("Should only allow manager to draw", async function () {
      await expect(lottery.connect(player1).draw()).to.be.reverted;
    });
  });

  describe("Refunding", function () {
    it("Should refund tokens to players", async function () {
      await myERC20.connect(player1).airdrop();
      const lotteryAddress = lottery.target || lottery.address;
      await myERC20.connect(player1).approve(lotteryAddress, 1000);
      
      // 记录投注前的余额
      const balanceBeforePlay = await myERC20.balanceOf(player1.address);
      expect(balanceBeforePlay).to.equal(10000);
      
      // 玩家投注
      await lottery.connect(player1).play();
      
      // 投注后的余额（应该减少500）
      const balanceAfterPlay = await myERC20.balanceOf(player1.address);
      expect(balanceAfterPlay).to.equal(10000 - 500);
      
      // 退款
      await lottery.refund();
      
      // 退款后的余额（应该恢复到10000）
      const balanceAfterRefund = await myERC20.balanceOf(player1.address);
      expect(balanceAfterRefund).to.equal(10000);
      
      expect(await lottery.getPlayerNumber()).to.equal(0);
      expect(await lottery.totalAmount()).to.equal(0);
    });

    it("Should only allow manager to refund", async function () {
      await expect(lottery.connect(player1).refund()).to.be.reverted;
    });
  });
});
