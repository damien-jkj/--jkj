import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";

const config: HardhatUserConfig = {
  solidity: "0.8.9",
  networks: {
    ganache: {
      url: 'HTTP://127.0.0.1:8545',
      accounts: [
        '72da03a70581c1c10e657433744f2fe0f5c5cd9b72dea1e95b557f2075c2aa9a',
        '47ec09ff73e37e0fe4e246b4f676f7dd81f7f9322915d16e9d29a5138a2cc49d',
        'bb128b940eb39330ff19c587eea96cec20323b031812829e1b7d47ad587712ee',
        '3fdb929fedec697b299a2a0e077677ad24655c3e6a800e4e1c4b32d99d3c3a8b',
        '726174c3bf89e2c23f9f0171bcff58a72cf9298121ca6edb6fd0e3ce4e0f9aca',
        'a7030d9e389462523c698f6f100db644a1ca51d6f1c07ace6911d4c55f64312c',
        '74bae7a3724759f301075459c2f95e6efbe495c49c36f51d16d5b9907200d796',
        'ebbb22efb2170e3519b0f2e27d75af595ff93346a999a00d2c78e103c65ee17f',
        '9cada656ed5c8d614399d9aae48c247d74f591c44c7e3b852bbb90205a5b50f8',
        'f17978c0056c317fa70960e963ca3772408bfdf439db5fd69b2ed17f8735ade2',
      ]
    },
  },
  paths: {
    sources: "./contracts",
    tests: "./test",
    cache: "./cache",

    artifacts: "./artifacts"
  },
};

export default config;
